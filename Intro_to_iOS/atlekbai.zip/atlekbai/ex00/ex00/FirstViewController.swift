//
//  FirstViewController.swift
//  ex00
//
//  Created by Alimukhamed TLEKBAI on 6/2/18.
//  Copyright © 2018 Alimukhamed TLEKBAI. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class FirstViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    let region_rad: CLLocationDistance = 1000
    let locationManager = CLLocationManager()
    var obj: Object?
    
    @IBAction func segControlChanged(_ sender: Any) {
        switch (sender as AnyObject).selectedSegmentIndex {
        case 0:
            mapView.mapType = .standard
        case 1:
            mapView.mapType = .satellite
        default:
            mapView.mapType = .hybrid
        }
    }
    
    func center_to_point(location: CLLocation)
    {
        let coordinate = MKCoordinateRegionMakeWithDistance(location.coordinate, region_rad, region_rad)
        mapView.setRegion(coordinate, animated: true)
    }
    
    @IBAction func userLocation(_ sender: Any) {
        let userLoc = mapView.userLocation
        let region = MKCoordinateRegionMakeWithDistance(userLoc.coordinate, 1000, 1000)
        mapView.setRegion(region, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        mapView.showsUserLocation = true
        mapView.delegate = self
        
        if let sentLoc = obj {
            let chosen_loc = Location(title: sentLoc.name, locationName: sentLoc.subtitle, lat: sentLoc.lat, lon: sentLoc.lon)
            mapView.addAnnotation(chosen_loc)
            center_to_point(location: chosen_loc.zoom)
        } else {
            let initloc = CLLocation(latitude: 50.463376, longitude: 30.480329)
            center_to_point(location: initloc)
        }
    }
}

extension FirstViewController : MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let annotation = annotation as? Location else {return nil}
        let identifier = "marker"
        var view: MKMarkerAnnotationView
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            as? MKMarkerAnnotationView{
            dequeuedView.annotation = annotation
            view = dequeuedView
        } else {
            view = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
            view.calloutOffset = CGPoint(x: 0, y: 5)
            let mapsButton = UIButton(frame: CGRect(origin: CGPoint.zero, size: CGSize(width: 30, height: 30)))
            mapsButton.setBackgroundImage(UIImage(named: "Maps-icon"), for: UIControlState())
            view.rightCalloutAccessoryView = mapsButton
        }
        return view
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        let location = view.annotation as! Location
        let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeWalking]
        location.mapItem().openInMaps(launchOptions: launchOptions)
    }
}
