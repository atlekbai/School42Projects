//
//  SecondViewController.swift
//  ex00
//
//  Created by Alimukhamed TLEKBAI on 6/2/18.
//  Copyright © 2018 Alimukhamed TLEKBAI. All rights reserved.
//

import UIKit

struct Object {
    var name: String
    var subtitle: String
    var id: Int
    var lat: Double
    var lon: Double
    var image : UIImage
}

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var tableView = UITableView()
    var objects = [Object]()
    var chos_id = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.frame = self.view.frame
        super.view.addSubview(tableView)
        tableView.delegate = self
        tableView.dataSource = self
        let bar1 = Object(name: "Lukianivska", subtitle: "Metro Station", id: 1, lat: 50.463376, lon: 30.480329, image: UIImage(named: "luk")!)
        let bar2 = Object(name: "Maidan", subtitle: "City Centre", id: 2, lat: 50.447486, lon: 30.526255, image: UIImage(named: "maidan")!)
        let bar3 = Object(name: "Rodina Mat'", subtitle: "Navodnicki Park", id: 3, lat: 50.426555, lon: 30.562966, image: UIImage(named: "mat")!)
        let bar4 = Object(name: "UNIT Factory", subtitle: "Educational Org.", id: 4, lat: 50.468757, lon: 30.462155, image: UIImage(named: "unit")!)
        objects.append(bar1)
        objects.append(bar2)
        objects.append(bar3)
        objects.append(bar4)
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return objects.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.contentView.layoutMargins.left = 0
        cell.contentView.layoutMargins.right = 0
        cell.accessoryView = UIImageView(image: objects[indexPath.section].image)
        cell.accessoryView?.frame = CGRect(x: 0, y: 0, width: 200, height: 100)
        cell.textLabel?.text = objects[indexPath.section].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        chos_id = indexPath.section
        performSegue(withIdentifier: "mapVC", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination
        vc.navigationItem.title = objects[chos_id].name
        if let destination = segue.destination as? FirstViewController {
            destination.obj = objects[chos_id]
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    override func viewWillAppear(_ animated: Bool) {
        if let index = self.tableView.indexPathForSelectedRow{
            self.tableView.deselectRow(at: index, animated: true)
        }
    }
}

