//
//  MoreVC.swift
//  ex00
//
//  Created by Alimukhamed TLEKBAI on 6/2/18.
//  Copyright © 2018 Alimukhamed TLEKBAI. All rights reserved.
//

import UIKit

class MoreVC: UIViewController {

    
    @IBAction func atlekbai(_ sender: Any) {
        UIApplication.shared.open(URL(string : "https://profile.intra.42.fr/users/atlekbai")!, options: [:], completionHandler: { (status) in
            
        })
    }
    @IBAction func vtolochk(_ sender: Any) {
        UIApplication.shared.open(URL(string : "https://profile.intra.42.fr/users/vtolochk")!, options: [:], completionHandler: { (status) in
            
        })
    }
    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
