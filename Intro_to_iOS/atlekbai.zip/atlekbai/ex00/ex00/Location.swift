//
//  Location.swift
//  ex00
//
//  Created by Alimukhamed TLEKBAI on 6/2/18.
//  Copyright © 2018 Alimukhamed TLEKBAI. All rights reserved.
//

import Foundation
import MapKit
import Contacts

class Location: NSObject, MKAnnotation {
    let title: String?
    let locationName: String
    let coordinate: CLLocationCoordinate2D
    let zoom: CLLocation
    
    init(title: String, locationName: String, lat: Double, lon: Double)
    {
        self.title = title
        self.locationName = locationName
        self.coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
        self.zoom = CLLocation(latitude: lat, longitude: lon)
        super.init()
    }
    
    var subtitle: String? {
        return locationName
    }
    func mapItem() -> MKMapItem {
        let addressDict = [CNPostalAddressStreetKey: subtitle!]
        let placemark = MKPlacemark(coordinate: coordinate, addressDictionary: addressDict)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = title
        return mapItem
    }
}
